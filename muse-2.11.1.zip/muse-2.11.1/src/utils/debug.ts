import debug from 'debug';

export default debug('muse');
