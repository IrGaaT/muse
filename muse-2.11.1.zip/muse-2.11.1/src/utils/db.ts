import Prisma from '@prisma/client';

export const prisma = new Prisma.PrismaClient();
