-- AlterTable
ALTER TABLE "Setting" ADD COLUMN "invitedByUserId" TEXT;
