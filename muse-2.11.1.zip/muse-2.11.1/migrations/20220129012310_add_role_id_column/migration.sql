-- AlterTable
ALTER TABLE "Setting" ADD COLUMN "roleId" TEXT;
